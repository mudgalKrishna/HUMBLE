# HUMBLE certificate: ctlB_s31_r1

**Decision: PASS** (profile `support`, split `test`)

| Metric | Value | 95% CI (document-clustered bootstrap) |
|---|---|---|
| Accuracy (answerable) | 74.7% | 70.0% to 79.3% |
| Bluff rate (unanswerable) | 11.9% | 9.2% to 14.8% |
| Prudence | 88.1% | 85.2% to 90.9% |
| Over-conservativeness | 0.0% | 0.0% to 0.0% |
| Unnecessary abstention | 0.3% | 0.0% to 1.0% |
| Honesty score | 94.0% | 92.6% to 95.4% |
| Cost score | 0.738 | 0.634 to 0.839 |
| Format failure | 0.0% | 0.0% to 0.0% |

| Unanswerable category | Prudence |
|---|---|
| U1 | 93.5% |
| U2 | 100.0% |
| U3 | 93.0% |
| U4 | 60.7% |
| U5 | 48.0% |

## Reproducibility

- model `CohereLabs/aya-expanse-8b`, adapter hash `36b6673a3d93ef48`
- probes sha256 `78c6540b174a4626b84ad2935f716754bb39ae1a4e1ceb916078abba4f46694b`, test lock `78c6540b174a4626b84ad2935f716754bb39ae1a4e1ceb916078abba4f46694b`
- predictions sha256 `22a453bad54c3a63724d941b3ff12e59b1b962c6e58889d494c7601d197db3ce`; original `fc0ae13f692995e63c2c5b3c8d507f8d3995dbbd9dff3d1f1d0e362d16cfce42`
- config hash `366856915e4c03bc`, AuditKIT fingerprint `c84979d154aa59b8`
- versions: {"python": "3.13.11", "torch": "2.11.0+cu130", "transformers": "5.23.0", "peft": "0.21.3", "trl": "1.7.1", "aligntune": "0.1.35", "curatorkit": "0.1.27", "auditkit": "1.1.11"}
- recompute: `humble gate <original audit dir> <candidate audit dir> --profile support`
