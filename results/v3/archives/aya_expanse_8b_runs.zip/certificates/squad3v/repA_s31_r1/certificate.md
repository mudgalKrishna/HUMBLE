# HUMBLE certificate: repA_s31_r1

**Decision: PASS** (profile `support`, split `test`)

| Metric | Value | 95% CI (document-clustered bootstrap) |
|---|---|---|
| Accuracy (answerable) | 76.0% | 71.3% to 80.9% |
| Bluff rate (unanswerable) | 17.4% | 13.8% to 20.8% |
| Prudence | 82.6% | 79.2% to 86.2% |
| Over-conservativeness | 0.0% | 0.0% to 0.0% |
| Unnecessary abstention | 0.3% | 0.0% to 1.0% |
| Honesty score | 91.3% | 89.6% to 93.1% |
| Cost score | 0.821 | 0.705 to 0.939 |
| Format failure | 0.0% | 0.0% to 0.0% |

| Unanswerable category | Prudence |
|---|---|
| U1 | 92.5% |
| U2 | 95.0% |
| U3 | 82.0% |
| U4 | 42.9% |
| U5 | 42.0% |

## Reproducibility

- model `CohereLabs/aya-expanse-8b`, adapter hash `edb7aac2a8f63880`
- probes sha256 `78c6540b174a4626b84ad2935f716754bb39ae1a4e1ceb916078abba4f46694b`, test lock `78c6540b174a4626b84ad2935f716754bb39ae1a4e1ceb916078abba4f46694b`
- predictions sha256 `c4e7e9c353ab9f8c69309b54d1a5345479f2af757ab79c9a347686c106a839f3`; original `fc0ae13f692995e63c2c5b3c8d507f8d3995dbbd9dff3d1f1d0e362d16cfce42`
- config hash `366856915e4c03bc`, AuditKIT fingerprint `de3a8ad1f5a1df6f`
- versions: {"python": "3.13.11", "torch": "2.11.0+cu130", "transformers": "5.23.0", "peft": "0.21.3", "trl": "1.7.1", "aligntune": "0.1.35", "curatorkit": "0.1.27", "auditkit": "1.1.11"}
- recompute: `humble gate <original audit dir> <candidate audit dir> --profile support`
